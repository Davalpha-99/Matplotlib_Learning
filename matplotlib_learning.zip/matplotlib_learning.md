# Matplotlib Basics Tutorials


```python
import matplotlib.pyplot as plt
```


```python
#for getting the plots on the jupyter notebook screen.
%matplotlib inline
```


```python
import numpy as np
```


```python
x=np.linspace(0,5,10)
y=x**2
```


```python
#single plot on the canvas, between x and y.
#plt.margins(0) is used to start the plots from (0,0).
plt.plot(x,y,'r-')
plt.xlabel('X Label')
plt.ylabel('Y Label')
plt.title('Title')
plt.margins(0)
plt.show()
```


![png](output_5_0.png)



```python
#multiple plots on same canvas
#plt.subplot(<no. of rows>,<no. of columns>,<plot_no.>).
plt.subplot(1,2,1)
plt.plot(x,y,'g')
plt.xlabel('x-axis')
plt.ylabel('y-axis')
plt.title('x-v/s-y')
plt.margins(0)
plt.subplot(1,2,2)
plt.plot(y,x,'b')
plt.xlabel('y-axis')
plt.ylabel('x-axis')
plt.title('y-v/s-x')
plt.margins(0)
plt.show()
```


![png](output_6_0.png)



```python
#creating on your own canvas.
fig=plt.figure()   #fig creates a figure object.
axes = fig.add_axes([0.0,0.0,1.0,1.0])   #fig.add_axes add axes to your plot(canvas).
#the first two parameters are the co-ordinates of the left bottomost point of the axes.
#last two parameters in that list of floating point no. are length and breadth of the plot. 
#now this will plot on the axes of your canvas,to whichever parameter you pass.
axes.set_xlabel('X Label')
axes.set_ylabel('Y Label')
axes.set_title('title')
#for the third parameter.
#use 'o' to get only the data points.
#use 'o-' to get a solid line connecting those points.
#use 'o--' to distorted line connecting those points.
axes.plot(x,y,'o--')
axes.margins(0)
```


![png](output_7_0.png)



```python
#create a figure
fig1 = plt.figure()
#manually create the axes its location and size.
axes1 = fig1.add_axes([0,0,1,1])
axes2 = fig1.add_axes([0.1,0.6,0.4,0.3])

#and work on axes.
axes1.plot(x,y,'y--')
axes2.plot(y,x,'b--')

axes1.set_title('LARGER PLOT')
axes2.set_title('SMALLER PLOT')
axes1.margins(0)
axes2.margins(0)
```


![png](output_8_0.png)



```python
#sublots using oops.
#here axes is an 2-d array of canvas(here 2*2),since the call to sub-plot asks for 2 row and 2 columns. 
#figsize parameter is used to choose the dimensions of each plot.
fig2,axes=plt.subplots(2,2,figsize=(7,7))
#for avoiding overlapping of various plots.
#use plt.tight_layout()
axes[0][0].plot(x,y,color='g',ls="-.",lw=2,marker='*',markersize=10)
axes[0][0].margins(0)
axes[0][0].set_title('First Plot')
axes[0][0].set_xlabel('<---X--->')
axes[0][0].set_ylabel('<---Y--->')
axes[0][1].plot(y,x,color='orange',ls="-.",lw=2,marker='+',markersize=10)
axes[0][1].margins(0)
axes[0][1].set_title('Second Plot')
axes[0][1].set_xlabel('<---Y--->')
axes[0][1].set_ylabel('<---X--->')
axes[1][0].plot(x,x,color='r',ls="-.",lw=2,marker='o',markersize=8)
axes[1][0].margins(0)
axes[1][0].set_title('Third Plot')
axes[1][0].set_xlabel('<---X--->')
axes[1][0].set_ylabel('<---X--->')
axes[1][1].plot(y,y,color='b',ls="-.",lw=2,marker='2',markersize=10)
axes[1][1].margins(0)
axes[1][1].set_title('Fourth Plot')
axes[1][1].set_xlabel('<---Y--->')
axes[1][1].set_ylabel('<---Y--->')
plt.tight_layout()
```


![png](output_9_0.png)


# Figure Size and DPI and Saving Figures


```python
#dpi is dots per inch on your figure.
#figure size is used to set the length and width of the plot,canvas.
#plt.figure(nrows=x,ncols=y,figsize=(<len>,<wid>)).
```


```python
#to save a figure use <fig object of plt.figure() call>.savefig('<filename.ext>',dpi=if you need)
fig.savefig('fig.png')
fig1.savefig('fig1.png')
fig2.savefig('fig2.png')
```


```python
#sublots using oops.
#here axes is an 2-d array of canvas(here 2*2),since the call to sub-plot asks for 2 row and 2 columns. 
#figsize parameter is used to choose the dimensions of each plot.
fig3,axes1=plt.subplots(1,2,figsize=(10,5))
axes1[0].margins(0)
axes1[1].margins(0)
#for avoiding overlapping of various plots.
#use plt.tight_layout()
axes1[0].set_title('FIRST PLOT')
axes1[0].plot(x,y,'g--',label='x-v/s-y')
axes1[0].plot(y,x,'b-',label='y-v/s-x')
axes1[1].set_title('SECOND PLOT')
axes1[1].plot(y,x,'r-',label='y-v/s-x')
axes1[1].plot(y,y,'o--',label='y-v/s-y')

axes1[0].legend(loc=0)
axes1[1].legend(loc=0)
plt.tight_layout()
```


![png](output_13_0.png)



```python
fig3.savefig('fig3.png')
```

# Plot Appearance


```python
#to change the look of the plot, you need to pass the arguments namely, color="<color name>" or "<RGB hex-codes>"
#to change the line_width you need to set linewidth=<val>
#to change the opacity of this line, set alpha=<val>
#lesser the alpha more transparent is the figure.

fig4 = plt.figure()
axes2 = fig4.add_axes([0,0,1,1])
axes2.margins(0)
axes2.plot(x,y,color="red",linewidth=2,alpha=1,linestyle="-.")
```




    [<matplotlib.lines.Line2D at 0x1bfd1ffd7b8>]




![png](output_16_1.png)



```python
#possible marker options ="+"","o","*,"s",",",".","1","2","3"
fig5 =plt.figure()

axes3= fig5.add_axes([0,0,1,1])
axes3.plot(x,y,color="y",lw=2,alpha=0.7,ls="dashed",marker="*",
          markersize=15,markeredgewidth=2,markeredgecolor="black",
          markerfacecolor="g")
axes3.margins(0)
fig5.savefig('fig5.pdf')
```


![png](output_17_0.png)



```python
fig6 =plt.figure()

#for getting a part of the plot, use set_xlim and set_ylim.
axes4= fig6.add_axes([0,0,1,1])
axes4.plot(x,y,color="b",lw=2,alpha=0.8,ls="--",marker="o",
          markerfacecolor='y',markersize=12)
#axes.set_xlim([<upper_lim>,<lower_lim>])=for setting the x limits.
#axes.set_ylim([<upper_lim>,<lower_lim>])=for setting the y limits.
axes4.set_xlim([0,3])
axes4.set_ylim([0,9])
axes4.margins(0)
fig6.savefig('fig6.pdf')
```


![png](output_18_0.png)



# _ THE END_
